/**
 * Report result JavaScript functionality using Google Charts.
 */
(function ($, Drupal, drupalSettings) {
  'use strict';

  Drupal.behaviors.reportResult = {
    attach: function (context, settings) {
      // Load Google Charts from CDN if not already loaded
      this.loadGoogleCharts(context);
      
      // Initialize coaching impact charts
      this.initializeCoachingImpactCharts(context, settings);
    },

    /**
     * Load Google Charts library from CDN.
     */
    loadGoogleCharts: function (context) {
      if (typeof google === 'undefined' || !google.charts) {
        var script = document.createElement('script');
        script.src = 'https://www.gstatic.com/charts/loader.js';
        script.onload = function() {
          google.charts.load('current', {'packages':['corechart']});
          google.charts.setOnLoadCallback(function() {
            // Trigger any pending chart renders
            $(document).trigger('googlecharts:loaded');
            // Re-initialize charts after Google Charts loads
            Drupal.behaviors.reportResult.initializeCoachingImpactCharts(context, settings);
          });
        };
        document.head.appendChild(script);
      } else {
        // Google Charts is already loaded, initialize immediately
        this.initializeCoachingImpactCharts(context, settings);
      }
    },

    /**
     * Initialize coaching impact charts using Google Charts.
     */
    initializeCoachingImpactCharts: function (context, settings) {
      if (typeof google === 'undefined' || !google.charts || !settings.coachingImpact) {
        console.log('Google Charts not ready or no coaching data available');
        return;
      }

      var coachingData = settings.coachingImpact;
      console.log('Initializing charts with data:', coachingData);
      
      // Behavioral Progress Chart
      if (coachingData.behavioralChartId && document.getElementById(coachingData.behavioralChartId)) {
        console.log('Creating behavioral chart for element:', coachingData.behavioralChartId);
        
        var behavioralData = google.visualization.arrayToDataTable([
          ['Period', 'Progress'],
          [coachingData.periodDisplay, coachingData.behavioralPercentage]
        ]);

        var behavioralOptions = {
          title: 'Behavioral Progress',
          titleTextStyle: {
            fontSize: 10,
            color: '#74788d',
            bold: false
          },
          height: 290,
          width: '100%',
          backgroundColor: 'transparent',
          chartArea: {
            left: 50,
            top: 50,
            width: '80%',
            height: '70%'
          },
          hAxis: {
            title: '',
            textStyle: {
              fontSize: 12,
              color: '#373d3f'
            }
          },
          vAxis: {
            title: '',
            minValue: 0,
            maxValue: 100,
            textStyle: {
              fontSize: 11,
              color: '#373d3f'
            },
            gridlines: {
              color: '#f1f1f1'
            }
          },
          colors: ['#5b73e8'],
          legend: {
            position: 'top',
            alignment: 'end',
            textStyle: {
              fontSize: 12,
              color: '#373d3f'
            }
          },
          bar: {
            groupWidth: '60%'
          }
        };

        try {
          var behavioralChart = new google.visualization.ColumnChart(
            document.getElementById(coachingData.behavioralChartId)
          );
          behavioralChart.draw(behavioralData, behavioralOptions);
          console.log('Behavioral chart created successfully');
        } catch (error) {
          console.error('Error creating behavioral chart:', error);
        }
      } else {
        console.log('Behavioral chart element not found:', coachingData.behavioralChartId);
      }

      // On-The-Job Progress Chart
      if (coachingData.onjobChartId && document.getElementById(coachingData.onjobChartId)) {
        console.log('Creating on-the-job chart for element:', coachingData.onjobChartId);
        
        var onjobData = google.visualization.arrayToDataTable([
          ['Period', 'Progress'],
          [coachingData.periodDisplay, coachingData.onjobPercentage]
        ]);

        var onjobOptions = {
          title: 'On-The-Job Progress',
          titleTextStyle: {
            fontSize: 10,
            color: '#74788d',
            bold: false
          },
          height: 290,
          width: '100%',
          backgroundColor: 'transparent',
          chartArea: {
            left: 50,
            top: 50,
            width: '80%',
            height: '70%'
          },
          hAxis: {
            title: '',
            textStyle: {
              fontSize: 12,
              color: '#373d3f'
            }
          },
          vAxis: {
            title: '',
            minValue: 0,
            maxValue: 100,
            textStyle: {
              fontSize: 11,
              color: '#373d3f'
            },
            gridlines: {
              color: '#f1f1f1'
            }
          },
          colors: ['#5b73e8'],
          legend: {
            position: 'top',
            alignment: 'end',
            textStyle: {
              fontSize: 12,
              color: '#373d3f'
            }
          },
          bar: {
            groupWidth: '60%'
          }
        };

        try {
          var onjobChart = new google.visualization.ColumnChart(
            document.getElementById(coachingData.onjobChartId)
          );
          onjobChart.draw(onjobData, onjobOptions);
          console.log('On-the-job chart created successfully');
        } catch (error) {
          console.error('Error creating on-the-job chart:', error);
        }
      } else {
        console.log('On-the-job chart element not found:', coachingData.onjobChartId);
      }
    }
  };

})(jQuery, Drupal, drupalSettings);