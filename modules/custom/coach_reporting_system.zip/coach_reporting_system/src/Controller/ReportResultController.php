<?php

namespace Drupal\coach_reporting_system\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Request;
use Drupal\coach_reporting_system\Utility\QuestionnaireMatrixTrait;

/**
 * Controller for displaying report results with tabs.
 */
class ReportResultController extends ControllerBase {
  use QuestionnaireMatrixTrait;

  /**
   * Display the report results with tabs.
   */
  public function viewResult(Request $request): array {
    try {
      $query_params = $request->query->all();

      // Validate required parameters
      $required_params = ['company', 'program', 'employee'];
      foreach ($required_params as $param) {
        if (empty($query_params[$param])) {
          $this->messenger()->addError($this->t('Missing required parameter: @param', ['@param' => $param]));
          return $this->redirect('coach_reporting_system.report');
        }
      }

      $company_uid   = (int) $query_params['company'];
      $program_nid   = (int) $query_params['program'];
      $employee_uid  = (int) $query_params['employee'];
      $coach_uid     = !empty($query_params['coach']) && $query_params['coach'] !== 'all' ? (int) $query_params['coach'] : NULL;
      $report_type   = $query_params['report_type'] ?? 'latest';
      $report_content = $query_params['report_content'] ?? [];
      $from_date     = $query_params['from'] ?? NULL;
      $to_date       = $query_params['to'] ?? NULL;

      if (!is_array($report_content)) {
        $report_content = [];
      }

      // Load entities
      $company  = $this->entityTypeManager()->getStorage('user')->load($company_uid);
      $program  = $this->entityTypeManager()->getStorage('node')->load($program_nid);
      $employee = $this->entityTypeManager()->getStorage('user')->load($employee_uid);
      $coach    = $coach_uid ? $this->entityTypeManager()->getStorage('user')->load($coach_uid) : NULL;

      if (!$company || !$program || !$employee) {
        $this->messenger()->addError($this->t('Invalid company, program, or employee selected.'));
        return $this->redirect('coach_reporting_system.report');
      }

      // Build the report with tabs
      $build = [
        '#type' => 'container',
        '#attributes' => ['class' => ['report-result-tabs']],
        '#attached' => [
          'library' => ['coach_reporting_system/report_result'],
        ],
      ];

      // Employee details
      $build['employee_details'] = $this->buildEmployeeDetails($company, $program, $employee, $report_type, $from_date, $to_date);

      // Tabs
      $build['tabs'] = $this->buildDynamicTabs($report_content, $query_params, $company_uid, $program_nid, $coach_uid, $employee_uid, $report_type, $from_date, $to_date);

      return $build;
    }
    catch (\Exception $e) {
      \Drupal::logger('coach_reporting_system')->error('Error in viewResult: @message', ['@message' => $e->getMessage()]);
      $this->messenger()->addError($this->t('An error occurred while loading the report. Please try again.'));
      return $this->redirect('coach_reporting_system.report');
    }
  }

  /**
   * Build dynamic tabs based on selected report content.
   */
  protected function buildDynamicTabs($report_content, $query_params, $company_uid, $program_nid, $coach_uid, $employee_uid, $report_type, $from_date, $to_date): array {
    $report_types = [
      'per_person' => [
        'title' => $this->t('Per Person'),
        'description' => $this->t('Individual performance metrics and competency scores'),
        'icon' => 'person',
      ],
      'competency_analysis' => [
        'title' => $this->t('Competency Analysis'),
        'description' => $this->t('Performance analysis over time and across periods'),
        'icon' => 'analytics',
      ],
      'on_job_performance' => [
        'title' => $this->t('On-The-Job Performance Results'),
        'description' => $this->t('Actual workplace performance metrics and achievements'),
        'icon' => 'work',
      ],
      'coaching_impact' => [
        'title' => $this->t('Coaching Impact on Performance'),
        'description' => $this->t('Impact measurement of coaching interventions'),
        'icon' => 'trending_up',
      ],
      'one_to_one_coaching' => [
        'title' => $this->t('Coaching One to One Report'),
        'description' => $this->t('Individual coaching sessions and development plans'),
        'icon' => 'psychology',
      ],
    ];

    if (empty($report_content)) {
      $report_content = array_keys($report_types);
    }

    $nav_tabs = [];
    $tab_panes = [];
    $active_tab = TRUE;

    foreach ($report_types as $key => $config) {
      if (in_array($key, $report_content, TRUE)) {
        $nav_tabs[$key . '_tab'] = [
          '#type' => 'link',
          '#title' => $config['title'],
          '#url' => \Drupal\Core\Url::fromRoute('<current>', [], [
            'fragment' => 'tab-' . $key,
            'query' => $query_params,
          ]),
          '#attributes' => [
            'class' => ['nav-link', $active_tab ? 'active' : ''],
            'data-toggle' => 'tab',
            'role' => 'tab',
            'aria-controls' => 'tab-' . $key,
            'aria-selected' => $active_tab ? 'true' : 'false',
            'title' => $config['description'],
          ],
        ];

        $tab_panes[$key . '_pane'] = [
          '#type' => 'container',
          '#attributes' => [
            'class' => ['tab-pane', 'fade', $active_tab ? 'show active' : ''],
            'id' => 'tab-' . $key,
            'role' => 'tabpanel',
            'aria-labelledby' => 'tab-' . $key,
          ],
          'content' => $this->buildReportContent($key, $company_uid, $program_nid, $coach_uid, $employee_uid, $report_type, $from_date, $to_date),
        ];

        $active_tab = FALSE;
      }
    }

    if (empty($nav_tabs)) {
      return [
        '#type' => 'container',
        '#attributes' => ['class' => ['no-tabs-message']],
        'content' => [
          '#markup' => '<div class="alert alert-warning"><strong>' . $this->t('No report types selected.') . '</strong> ' . $this->t('Please select at least one report type from the form.') . '</div>',
        ],
      ];
    }

    return [
      '#type' => 'container',
      '#attributes' => ['class' => ['report-tabs']],
      'nav' => [
        '#type' => 'container',
        '#attributes' => [
          'class' => ['nav', 'nav-tabs'],
          'role' => 'tablist',
        ],
        'tabs' => $nav_tabs,
      ],
      'content' => [
        '#type' => 'container',
        '#attributes' => ['class' => ['tab-content']],
        'panes' => $tab_panes,
      ],
    ];
  }

  /**
   * Build employee details section.
   */
  protected function buildEmployeeDetails($company, $program, $employee, $report_type, $from_date, $to_date): array {
    $date_display = '';
    if ($report_type === 'latest') {
      $date_display = date('d/m/Y');
    } elseif ($from_date && $to_date) {
      $date_display = $from_date . ' to ' . $to_date;
    }

    return [
      '#type' => 'container',
      '#attributes' => ['class' => ['employee-details']],
      'details' => [
        '#type' => 'container',
        '#attributes' => ['class' => ['details-container']],
        'left' => [
          '#type' => 'container',
          '#attributes' => ['class' => ['details-left']],
          'company_label' => ['#markup' => $this->t('Company')],
          'program_label' => ['#markup' => $this->t('Program')],
          'employee_label' => ['#markup' => $this->t('Employee')],
          'date_label' => ['#markup' => $this->t('Date') . ' <small>(DD/MM/YY)</small>'],
        ],
        'right' => [
          '#type' => 'container',
          '#attributes' => ['class' => ['details-right']],
          'company_value' => ['#markup' => $company->label()],
          'program_value' => ['#markup' => $program->label()],
          'employee_value' => ['#markup' => $employee->label()],
          'date_value' => ['#markup' => $date_display],
        ],
      ],
      'buttons' => [
        '#type' => 'container',
        '#attributes' => ['class' => ['details-buttons']],
        'download' => [
          '#type' => 'link',
          '#title' => $this->t('DOWNLOAD REPORT'),
          '#url' => \Drupal\Core\Url::fromRoute('coach_reporting_system.report_result', [], [
            'query' => \Drupal::request()->query->all() + ['download' => '1']
          ]),
          '#attributes' => ['class' => ['coaching-button']],
        ],
        'close' => [
          '#type' => 'link',
          '#title' => $this->t('CLOSE'),
          '#url' => \Drupal\Core\Url::fromRoute('coach_reporting_system.report'),
          '#attributes' => ['class' => ['coaching-button']],
        ],
      ],
    ];
  }

  /**
   * Build report content for a specific report type.
   */
  protected function buildReportContent($report_type, $company_uid, $program_nid, $coach_uid, $employee_uid, $report_type_param, $from_date, $to_date): array {
    switch ($report_type) {
      case 'per_person':
        return $this->buildPerPersonContent($company_uid, $program_nid, $coach_uid, $employee_uid, $report_type_param, $from_date, $to_date);

      case 'competency_analysis':
        return $this->buildCompetencyAnalysisContent($company_uid, $program_nid, $coach_uid, $employee_uid, $report_type_param, $from_date, $to_date);

      case 'on_job_performance':
        return $this->buildOnJobPerformanceContent($company_uid, $program_nid, $coach_uid, $employee_uid, $report_type_param, $from_date, $to_date);

      case 'coaching_impact':
        return $this->buildCoachingImpactContent($company_uid, $program_nid, $coach_uid, $employee_uid, $report_type_param, $from_date, $to_date);

      case 'one_to_one_coaching':
        return $this->buildOneToOneCoachingContent($company_uid, $program_nid, $coach_uid, $employee_uid, $report_type_param, $from_date, $to_date);

      default:
        return ['#markup' => '<p>' . $this->t('Report type not implemented yet.') . '</p>'];
    }
  }

  /**
   * Build Per Person report content.
   */
  protected function buildPerPersonContent($company_uid, $program_nid, $coach_uid, $employee_uid, $report_type, $from_date, $to_date): array {
    $employee = $this->entityTypeManager()->getStorage('user')->load($employee_uid);
    $employee_name = $employee ? $employee->label() : 'Employee ' . $employee_uid;

    return [
      '#type' => 'container',
      '#attributes' => ['class' => ['per-person-report']],
      'content' => [
        '#markup' => $this->buildPerPersonTable($employee_name, $company_uid, $program_nid, $employee_uid, $report_type, $from_date, $to_date),
      ],
    ];
  }

 /**
 * Dynamic Per-Person table (formatted as requested) with 0–100 normalization
 * based on the number of matrix options (even spacing).
 */
protected function buildPerPersonTable($employee_name, $company_uid, $program_nid, $employee_uid, $report_type, $from_date, $to_date): string {
  $db = \Drupal::database();
  $program = $this->entityTypeManager()->getStorage('node')->load((int) $program_nid);
  if (!$program) {
    return '<div class="messages messages--error">'.$this->t('Questionnaire not found.').'</div>';
  }

  // 1) Extract dynamic matrix from Questionnaire paragraphs.
  $steps = $this->buildStepsFromField($program, 'field_create_questionnaire');
  $matrix_def = NULL;
  foreach ($steps as $s) {
    if (($s['widget'] ?? '') === 'matrix') { $matrix_def = $s['def']; break; }
  }
  if (!$matrix_def || empty($matrix_def['rows']) || empty($matrix_def['options'])) {
    return '<div class="messages messages--warning">'.$this->t('This questionnaire has no matrix to report.').'</div>';
  }

  // Keep only headings and questions in order. (type: heading/question; id = row_uuid; label)
  $rows = array_values(array_filter($matrix_def['rows'], fn($r) => in_array($r['type'], ['heading', 'question'], TRUE)));

  // --- Build normalization map (EVENLY spaced 0..100 over the number of options) ---
  // We keep the order as provided by $matrix_def['options'].
  $columns      = $matrix_def['options'];     // key => label (keys can be strings/numbers)
  $option_keys  = array_keys($columns);       // preserve order
  $option_count = max(1, count($option_keys));
  $den          = max(1, $option_count - 1);  // avoid div-by-zero (single option -> always 0)

  // raw stored value (as string) -> normalized percent (float)
  $normalize_map = [];
  foreach (array_values($option_keys) as $i => $rawKey) {
   /* $normalize_map[(string) $rawKey] = ($i * 100.0) / $den;  // e.g. 0,25,50,75,100 (5 options)*/
    $normalize_map[(string)$rawKey] = 100 - ($i * 100.0 / $den);
  }

  // 2) Load submitted sessions for this employee/program/company.
  $q = $db->select('coach_reporting_session', 's')
    ->fields('s', ['sid','submitted'])
    ->condition('company_uid', (int) $company_uid)
    ->condition('program_nid', (int) $program_nid)
    ->condition('employee_uid', (int) $employee_uid)
    ->isNotNull('submitted');

  $is_overtime = ($report_type === 'overtime');
  if ($is_overtime && $from_date && $to_date) {
    try {
      $from_ts = strtotime($from_date . ' 00:00:00') ?: 0;
      $to_ts   = strtotime($to_date   . ' 23:59:59') ?: 0;
      if ($from_ts && $to_ts) {
        $q->condition('submitted', [$from_ts, $to_ts], 'BETWEEN');
      }
    } catch (\Throwable $e) {}
    $q->orderBy('submitted', 'ASC');
  }
  else {
    $q->orderBy('submitted', 'DESC')->range(0, 1);
  }

  $sessions = $q->execute()->fetchAllAssoc('sid');
  if (!$sessions) {
    return '<div class="messages messages--warning">'.$this->t('No submitted sessions found for the chosen filters.').'</div>';
  }
  $sid_list = array_keys($sessions);

  // 3) Load answers for these sessions + NORMALIZE
  $ans_q = $db->select('coach_reporting_session_answer', 'a')
    ->fields('a', ['sid','row_uuid','value'])
    ->condition('sid', $sid_list, 'IN');
  $answers = $ans_q->execute()->fetchAll();

  // by row_uuid => [normalized values...]
  $by_row_values = [];
  foreach ($answers as $a) {
    $rowUuid = (string) $a->row_uuid;
    if ($rowUuid === '') { continue; }

    $norm = NULL;
    $raw  = (string) $a->value;

    if ($raw !== '' && array_key_exists($raw, $normalize_map)) {
      // Direct match in options → normalize by position.
      $norm = $normalize_map[$raw];
    }
    else {
      // Try integer-cast match (covers "100" vs 100 stored etc.)
      $intKey = (string) ((int) $raw);
      if ($raw !== '' && array_key_exists($intKey, $normalize_map)) {
        $norm = $normalize_map[$intKey];
      }
      elseif (is_numeric($raw)) {
        // If it's a numeric percent already, clamp 0..100 and use it directly.
        $pct  = (float) $raw;
        $norm = max(0.0, min(100.0, $pct));
      } else {
        // Unknown value; skip.
        continue;
      }
    }

    if ($is_overtime) {
      $by_row_values[$rowUuid][] = $norm;
    } else {
      $by_row_values[$rowUuid] = [$norm];
    }
  }

  // Helper to average arrays safely.
  $avg = static function(array $nums): ?float {
    $nums = array_values(array_filter($nums, fn($v) => is_numeric($v)));
    if (!$nums) { return NULL; }
    return array_sum($nums) / count($nums);
  };

  // Compute final per-question normalized score (0..100).
  $per_question_score = [];
  foreach ($rows as $r) {
    if ($r['type'] !== 'question') { continue; }
    $rid = (string) $r['id'];
    if (!empty($by_row_values[$rid])) {
      $per_question_score[$rid] = $is_overtime ? $avg($by_row_values[$rid]) : reset($by_row_values[$rid]);
    } else {
      $per_question_score[$rid] = NULL;
    }
  }

  // 4) Build the requested data structure (categories with subcategories).
  $competencies = []; // [ [category => 'X', subcategories => [ [name => 'q', score => 0..100], ... ] ], ... ]
  $current_category = NULL;
  foreach ($rows as $r) {
    if ($r['type'] === 'heading') {
      $current_category = $r['label'];
      $competencies[] = ['category' => $current_category, 'subcategories' => []];
      continue;
    }
    if ($r['type'] === 'question') {
      if ($current_category === NULL) {
        $current_category = (string) $this->t('General');
        $competencies[] = ['category' => $current_category, 'subcategories' => []];
      }
      $rid   = (string) $r['id'];
      $score = $per_question_score[$rid] ?? NULL; // already 0..100 normalized
      $competencies[count($competencies)-1]['subcategories'][] = [
        'name'  => $r['label'],
        'score' => $score === NULL ? NULL : (float) $score,
      ];
    }
  }

  // Compute per-competency averages (still 0..100 scale).
  $competency_avg = [];
  foreach ($competencies as $idx => $comp) {
    $vals = [];
    foreach ($comp['subcategories'] as $sc) {
      if ($sc['score'] !== NULL) { $vals[] = (float) $sc['score']; }
    }
    $competency_avg[$idx] = $vals ? $avg($vals) : NULL;
  }

  // 5) Render HTML per requested format
  $esc = fn($s) => \Drupal\Component\Utility\Html::escape((string) $s);
  $session_count = count($sid_list);

  $style = '';

  $html = $style;
  $html .= '<div class="per-person-table-container">
    <table class="competency-table">
      <thead>
        <tr>
          <th class="competency-header">'.$this->t('Competency').'</th>
          <th class="score-header">'.$esc($employee_name).' ('.$session_count.'*)</th>
          <th class="average-header">'.$this->t('Overall average per Competency').'</th>
        </tr>
      </thead>
      <tbody>';

  foreach ($competencies as $i => $comp) {
    $html .= '<tr class="category-row">
      <td class="category-cell" colspan="3">'.$esc($comp['category']).'</td>
    </tr>';

    $avg_val = $competency_avg[$i];
    foreach ($comp['subcategories'] as $sc) {
      $val = $sc['score'];                           // 0..100 or NULL
      $val_for_color = $val ?? $avg_val ?? 0;        // color fallback
      $score_class = ($val_for_color >= 80) ? 'score-green' : (($val_for_color >= 60) ? 'score-yellow' : 'score-red');

      $score_text = ($val === NULL) ? '—' : (is_float($val) && fmod($val,1)!==0.0 ? number_format($val, 1) : (string) (int) round($val));
      $avg_text   = ($avg_val === NULL) ? '—' : (is_float($avg_val) && fmod($avg_val,1)!==0.0 ? number_format($avg_val, 1) : (string) (int) round($avg_val));

      $html .= '<tr class="subcategory-row">
        <td class="subcategory-cell">'.$esc($sc['name']).'</td>
        <td class="score-cell '.$score_class.'">'.$esc($score_text).'</td>
        <td class="average-cell '.$score_class.'">'.$esc($avg_text).'</td>
      </tr>';
    }
  }

  $html .= '</tbody>
    </table>
  </div>';

  return $html;
}

  /**
   * (Optional) Old sample implementation kept for reference.
   */
  protected function buildPerPersonTable_old($employee_name, $company_uid, $program_nid, $employee_uid, $report_type, $from_date, $to_date): string {
    // (unchanged from your sample)
    $html = '<div class="alert alert-info">'.$this->t('Old static sample removed for brevity.').'</div>';
    return $html;
  }

  // 1) Wrapper used by buildReportContent()
    protected function buildCompetencyAnalysisContent($company_uid, $program_nid, $coach_uid, $employee_uid, $report_type, $from_date, $to_date): array {
      return [
        '#type' => 'container',
        '#attributes' => ['class' => ['competency-analysis']],
        'content' => [
          '#markup' => $this->buildCompetencyAnalysisTable((int)$company_uid, (int)$program_nid, (int)$employee_uid),
        ],
      ];
    }
    
    // 2) Actual table builder
protected function buildCompetencyAnalysisTable(int $company_uid, int $program_nid, int $employee_uid): string {
  $db = \Drupal::database();
  $program = $this->entityTypeManager()->getStorage('node')->load($program_nid);
  if (!$program) {
    return '<div class="messages messages--error">'.$this->t('Questionnaire not found.').'</div>';
  }

  // --- Questionnaire structure + normalization map (reversed, even-spaced 0..100) ---
  $steps = $this->buildStepsFromField($program, 'field_create_questionnaire');
  $matrix_def = NULL;
  foreach ($steps as $s) { if (($s['widget'] ?? '') === 'matrix') { $matrix_def = $s['def']; break; } }
  if (!$matrix_def || empty($matrix_def['rows']) || empty($matrix_def['options'])) {
    return '<div class="messages messages--warning">'.$this->t('This questionnaire has no matrix to analyze.').'</div>';
  }

  $rows = array_values(array_filter($matrix_def['rows'], fn($r) => in_array($r['type'], ['heading','question'], TRUE)));

  $columns      = $matrix_def['options'];  // key => label (order matters)
  $option_keys  = array_keys($columns);
  $option_count = max(1, count($option_keys));
  $den          = max(1, $option_count - 1);

  // First option -> 100, last -> 0
  $normalize_map = [];
  foreach (array_values($option_keys) as $i => $rawKey) {
    $normalize_map[(string) $rawKey] = 100 - ($i * 100.0 / $den);
  }

  // --- Sessions: all (for full history), last 3 months, and latest ---
  $s_q = $db->select('coach_reporting_session', 's')
    ->fields('s', ['sid','fill_date'])
    ->condition('company_uid', $company_uid)
    ->condition('program_nid', $program_nid)
    ->condition('employee_uid', $employee_uid)
    ->isNotNull('submitted')
    ->orderBy('submitted', 'ASC');
  $sessions = $s_q->execute()->fetchAllAssoc('sid');
  if (!$sessions) {
    return '<div class="messages messages--warning">'.$this->t('No submitted sessions found for this employee.').'</div>';
  }

  $sid_all = array_keys($sessions);
  $now_ts = time();
  $three_months_ago = strtotime('-3 months', $now_ts) ?: ($now_ts - 90*86400);

  $sid_last_3m = [];
  foreach ($sessions as $sid => $obj) {
    $ts = (int) (strtotime($obj->fill_date) ?? 0);
    if ($ts >= $three_months_ago && $ts <= $now_ts) { $sid_last_3m[] = $sid; }
  }
  $sid_latest = [ end($sid_all) ?: reset($sid_all) ];

  // --- Answers (normalize to 0..100) ---
  $ans_q = $db->select('coach_reporting_session_answer', 'a')
    ->fields('a', ['sid','row_uuid','value'])
    ->condition('sid', $sid_all, 'IN');
  $answers = $ans_q->execute()->fetchAll();

  $answers_by_sid_row = []; // [sid][row_uuid] = normalized 0..100
  foreach ($answers as $a) {
    $sid = (int) $a->sid;
    $rid = (string) $a->row_uuid;
    if ($rid === '') { continue; }

    $norm = NULL;
    $raw  = (string) $a->value;

    if ($raw !== '' && array_key_exists($raw, $normalize_map)) {
      $norm = $normalize_map[$raw];
    } else {
      $intKey = (string)((int)$raw);
      if ($raw !== '' && array_key_exists($intKey, $normalize_map)) {
        $norm = $normalize_map[$intKey];
      } elseif (is_numeric($raw)) {
        $pct  = (float)$raw;
        $norm = max(0.0, min(100.0, $pct));
      } else {
        continue;
      }
    }

    $answers_by_sid_row[$sid][$rid] = $norm;
  }

  $avg = static function(array $nums): ?float {
    $nums = array_values(array_filter($nums, fn($v) => is_numeric($v)));
    return $nums ? array_sum($nums) / count($nums) : NULL;
  };

  $per_bucket = function(array $bucket) use ($rows, $answers_by_sid_row, $avg): array {
    $out = [];
    foreach ($rows as $r) {
      if ($r['type'] !== 'question') { continue; }
      $rid = (string)$r['id'];
      $vals = [];
      foreach ($bucket as $sid) {
        if (isset($answers_by_sid_row[$sid][$rid])) {
          $vals[] = (float)$answers_by_sid_row[$sid][$rid];
        }
      }
      $out[$rid] = $vals ? $avg($vals) : NULL;
    }
    return $out;
  };

  $pq_full   = $per_bucket($sid_all);
  $pq_last3  = $sid_last_3m ? $per_bucket($sid_last_3m) : [];
  $pq_latest = $per_bucket($sid_latest);

  // --- Build categories & compute competency averages per window ---
  $competencies = [];
  $current_category = NULL;
  foreach ($rows as $r) {
    if ($r['type'] === 'heading') {
      $current_category = $r['label'];
      $competencies[] = ['category' => $current_category, 'subcategories' => []];
      continue;
    }
    if ($r['type'] === 'question') {
      if ($current_category === NULL) {
        $current_category = (string)$this->t('General');
        $competencies[] = ['category' => $current_category, 'subcategories' => []];
      }
      $competencies[count($competencies)-1]['subcategories'][] = [
        'name' => $r['label'],
        'rid'  => (string)$r['id'],
      ];
    }
  }

  $comp_avg_full = $comp_avg_last3 = $comp_avg_latest = [];
  foreach ($competencies as $idx => $comp) {
    $vf = $vl3 = $vlt = [];
    foreach ($comp['subcategories'] as $sc) {
      $rid = $sc['rid'];
      if (array_key_exists($rid, $pq_full)   && $pq_full[$rid]   !== NULL) { $vf[]  = (float)$pq_full[$rid]; }
      if ($sid_last_3m && array_key_exists($rid, $pq_last3) && $pq_last3[$rid] !== NULL) { $vl3[] = (float)$pq_last3[$rid]; }
      if (array_key_exists($rid, $pq_latest) && $pq_latest[$rid] !== NULL) { $vlt[] = (float)$pq_latest[$rid]; }
    }
    $comp_avg_full[$idx]   = $vf  ? $avg($vf)  : NULL;
    $comp_avg_last3[$idx]  = $vl3 ? $avg($vl3) : NULL;
    $comp_avg_latest[$idx] = $vlt ? $avg($vlt) : NULL;
  }

  $esc = fn($s) => \Drupal\Component\Utility\Html::escape((string)$s);
  $fmt = static function($v) { return $v === NULL ? '—' : ((is_float($v) && fmod($v,1)!==0.0) ? number_format($v, 1) : (string)(int)round($v)); };

  $html = '<div class="competency-analysis-table-container">
    <table class="competency-table">
      <thead>
        <tr>
          <th class="competency-header">'.$this->t('Competency').'</th>
          <th class="avg-full">'.$this->t('Full History').'</th>
          <th class="avg-last3">'.$this->t('Previous 3 months').'</th>
          <th class="avg-latest">'.$this->t('Latest').'</th>
        </tr>
      </thead>
      <tbody>';

  foreach ($competencies as $i => $comp) {
    $html .= '<tr class="category-row"><td class="category-cell" colspan="4">'.$esc($comp['category']).'</td></tr>';

    $f  = $comp_avg_full[$i]   ?? NULL;
    $l3 = $comp_avg_last3[$i]  ?? NULL;
    $lt = $comp_avg_latest[$i] ?? NULL;

    foreach ($comp['subcategories'] as $sc) {
      $html .= '<tr class="subcategory-row">
        <td class="subcategory-cell">'.$esc($sc['name']).'</td>
        <td class="avg-full-cell">'.$esc($fmt($f)).'</td>
        <td class="avg-last3-cell">'.$esc($fmt($l3)).'</td>
        <td class="avg-latest-cell">'.$esc($fmt($lt)).'</td>
      </tr>';
    }
  }

  $html .= '</tbody></table></div>';

  return $html;
}



  protected function buildOnJobPerformanceContent($company_uid, $program_nid, $coach_uid, $employee_uid, $report_type, $from_date, $to_date): array {
    return [
      '#type' => 'container',
      '#attributes' => ['class' => ['on-job-performance']],
      'content' => [
        '#markup' => '<h3>' . $this->t('On-The-Job Performance Results') . '</h3>
        <p>' . $this->t('This report shows actual job performance metrics and results achieved in the workplace.') . '</p>
        <div class="alert alert-info">
          <strong>' . $this->t('Performance Categories:') . '</strong><br>
          ' . $this->t('Stars: 100%+ performance') . '<br>
          ' . $this->t('Core Performers: 60-99% performance') . '<br>
          ' . $this->t('Laggards: Less than 60% performance') . '
        </div>'
      ],
    ];
  }

  protected function buildCoachingImpactContent($company_uid, $program_nid, $coach_uid, $employee_uid, $report_type, $from_date, $to_date): array {
    return [
      '#type' => 'container',
      '#attributes' => ['class' => ['coaching-impact']],
      'content' => [
        '#markup' => '<h3>' . $this->t('Coaching Impact on Performance') . '</h3>
        <p>' . $this->t('This report measures the impact of coaching interventions on employee performance and development.') . '</p>
        <div class="alert alert-info">
          <strong>' . $this->t('Impact Metrics:') . '</strong><br>
          ' . $this->t('Behavioral Performance Results: Skills development progress') . '<br>
          ' . $this->t('On-The-Job Performance Results: Workplace achievement') . '<br>
          ' . $this->t('Cumulative Results: Combined performance indicators') . '
        </div>'
      ],
    ];
  }

  protected function buildOneToOneCoachingContent($company_uid, $program_nid, $coach_uid, $employee_uid, $report_type, $from_date, $to_date): array {
    return [
      '#type' => 'container',
      '#attributes' => ['class' => ['one-to-one-coaching']],
      'content' => [
        '#markup' => '<h3>' . $this->t('Coaching One to One Report') . '</h3>
        <p>' . $this->t('This report provides detailed insights from individual coaching sessions and personalized development plans.') . '</p>
        <div class="alert alert-info">
          <strong>' . $this->t('Session Details:') . '</strong><br>
          ' . $this->t('Individual coaching sessions') . '<br>
          ' . $this->t('Personal development plans') . '<br>
          ' . $this->t('Action items and follow-ups') . '<br>
          ' . $this->t('Progress tracking and ratings') . '
        </div>'
      ],
    ];
  }

  protected function checkForReportData($company_uid, $program_nid, $employee_uid, $report_type): bool {
    return TRUE;
  }
}
