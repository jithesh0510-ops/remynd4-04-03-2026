/**
 * Report Result JavaScript functionality
 */
(function (Drupal, drupalSettings) {
  'use strict';

  Drupal.behaviors.reportResult = {
    attach: function (context, settings) {
      // Initialize tab functionality
      this.initializeTabs(context);
      
      // Initialize color detection for performance indicators
      this.initializeColorDetection(context);
      
      // Initialize charts if ApexCharts is available
      this.initializeCharts(context);
      
      // Initialize select all functionality
      this.initializeSelectAll(context);
    },

    /**
     * Initialize tab functionality
     */
    initializeTabs: function(context) {
      const tabLinks = context.querySelectorAll('.nav-link[data-toggle="tab"]');
      const tabPanes = context.querySelectorAll('.tab-pane');
      
      tabLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
          e.preventDefault();
          
          // Remove active class from all tabs and panes
          tabLinks.forEach(function(tab) {
            tab.classList.remove('active');
            tab.setAttribute('aria-selected', 'false');
          });
          
          tabPanes.forEach(function(pane) {
            pane.classList.remove('show', 'active');
          });
          
          // Add active class to clicked tab
          this.classList.add('active');
          this.setAttribute('aria-selected', 'true');
          
          // Show corresponding tab pane
          const targetId = this.getAttribute('aria-controls');
          const targetPane = context.querySelector('#' + targetId);
          if (targetPane) {
            targetPane.classList.add('show', 'active');
          }
        });
      });
    },

    /**
     * Initialize color detection for performance indicators
     */
    initializeColorDetection: function(context) {
      const colorElements = context.querySelectorAll('.detect_color');
      colorElements.forEach(function(element) {
        const currentVal = element.innerHTML.replace('%', '');
        const numericVal = parseFloat(currentVal);
        
        let bgColor = '#FFDD7D'; // Default yellow
        let textColor = '#000000';
        
        if (numericVal >= 80) {
          bgColor = '#b3e2c7'; // Green
        } else if (numericVal <= 60) {
          bgColor = '#F95959'; // Red
          textColor = '#FFFFFF';
        }
        
        element.style.backgroundColor = bgColor;
        element.style.color = textColor;
      });
    },

    /**
     * Initialize ApexCharts if available
     */
    initializeCharts: function(context) {
      if (typeof ApexCharts !== 'undefined') {
        const chartContainers = context.querySelectorAll('.apex-charts');
        chartContainers.forEach(function(container) {
          const chartId = container.id;
          if (chartId && window['options_' + chartId]) {
            const chart = new ApexCharts(container, window['options_' + chartId]);
            chart.render();
          }
        });
      }
    },

    /**
     * Initialize select all functionality
     */
    initializeSelectAll: function(context) {
      const selectAllCheckbox = context.querySelector('.selectall');
      const individualCheckboxes = context.querySelectorAll('.individual');
      
      if (selectAllCheckbox && individualCheckboxes.length > 0) {
        // Handle select all checkbox change
        selectAllCheckbox.addEventListener('change', function() {
          individualCheckboxes.forEach(function(checkbox) {
            checkbox.checked = selectAllCheckbox.checked;
          });
        });
        
        // Handle individual checkbox changes
        individualCheckboxes.forEach(function(checkbox) {
          checkbox.addEventListener('change', function() {
            const checkedCount = Array.from(individualCheckboxes).filter(cb => cb.checked).length;
            selectAllCheckbox.checked = checkedCount === individualCheckboxes.length;
            selectAllCheckbox.indeterminate = checkedCount > 0 && checkedCount < individualCheckboxes.length;
          });
        });
      }
    }
  };

  /**
   * Export data functionality
   */
  Drupal.behaviors.exportData = {
    attach: function (context, settings) {
      const exportButtons = context.querySelectorAll('[data-export]');
      exportButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
          e.preventDefault();
          const tableId = this.getAttribute('data-export');
          Drupal.reportResult.exportTable(tableId);
        });
      });
    }
  };

  /**
   * Report result utility functions
   */
  Drupal.reportResult = {
    /**
     * Export table data
     */
    exportTable: function(tableId) {
      const table = document.getElementById(tableId);
      if (!table) {
        console.error('Table not found: ' + tableId);
        return;
      }

      let csv = [];
      const rows = table.querySelectorAll('tr');
      
      rows.forEach(function(row) {
        const cells = row.querySelectorAll('th, td');
        const rowData = [];
        cells.forEach(function(cell) {
          rowData.push('"' + cell.textContent.replace(/"/g, '""') + '"');
        });
        csv.push(rowData.join(','));
      });
      
      const csvContent = csv.join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'report_' + tableId + '_' + new Date().toISOString().split('T')[0] + '.csv';
      link.click();
      window.URL.revokeObjectURL(url);
    },

    /**
     * Show loading indicator
     */
    showLoading: function(container) {
      const loadingDiv = document.createElement('div');
      loadingDiv.className = 'loading';
      loadingDiv.textContent = Drupal.t('Loading results, please wait...');
      container.appendChild(loadingDiv);
    },

    /**
     * Hide loading indicator
     */
    hideLoading: function(container) {
      const loadingDiv = container.querySelector('.loading');
      if (loadingDiv) {
        loadingDiv.remove();
      }
    }
  };

})(Drupal, drupalSettings);
